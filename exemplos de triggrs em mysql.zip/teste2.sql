# MySQL-Front 5.0  (Build 1.0)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: teste2
# ------------------------------------------------------
# Server version 5.1.50-community

#
# Table structure for table tabela_02
#

DROP TABLE IF EXISTS `tabela_02`;
CREATE TABLE `tabela_02` (
  `Tabela_02` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Table_01_codigo` int(10) unsigned NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Tabela_02`),
  KEY `Tabela_02_FKIndex1` (`Table_01_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `tabela_02` VALUES (1,1,'120');
INSERT INTO `tabela_02` VALUES (3,2,'50');
INSERT INTO `tabela_02` VALUES (4,0,'100');
INSERT INTO `tabela_02` VALUES (5,2,'60');
INSERT INTO `tabela_02` VALUES (6,1,'300');
/*!40000 ALTER TABLE `tabela_02` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table table_01
#

DROP TABLE IF EXISTS `table_01`;
CREATE TABLE `table_01` (
  `codigo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `servico_descricao` varchar(255) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `table_01` VALUES (1,'mso',420);
INSERT INTO `table_01` VALUES (2,'sub_p',110);
/*!40000 ALTER TABLE `table_01` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for trigger NewTrigger
#

DROP TRIGGER IF EXISTS `NewTrigger`;
CREATE DEFINER='root'@`localhost` TRIGGER `NewTrigger` AFTER INSERT ON `tabela_02`
  FOR EACH ROW begin

update table_01 set total=total+New.item
where table_01.codigo=New.Table_01_codigo;

end;


#
# Source for trigger NewTrigger3
#

DROP TRIGGER IF EXISTS `NewTrigger3`;
CREATE DEFINER='root'@`localhost` TRIGGER `NewTrigger3` AFTER UPDATE ON `tabela_02`
  FOR EACH ROW begin
update table_01 set total=total-old.item
where table_01.codigo=old.Table_01_codigo;
update table_01 set total=total+New.item
where table_01.codigo=New.Table_01_codigo;
end;


#
# Source for trigger NewTrigger2
#

DROP TRIGGER IF EXISTS `NewTrigger2`;
CREATE DEFINER='root'@`localhost` TRIGGER `NewTrigger2` AFTER DELETE ON `tabela_02`
  FOR EACH ROW begin
update table_01 set total=total-old.item
where table_01.codigo=old.Table_01_codigo;
end;


/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
