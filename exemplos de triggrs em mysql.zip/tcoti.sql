# MySQL-Front 5.0  (Build 1.0)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: tcoti
# ------------------------------------------------------
# Server version 5.1.50-community

#
# Table structure for table agenda_vistoria_pc
#

DROP TABLE IF EXISTS `agenda_vistoria_pc`;
CREATE TABLE `agenda_vistoria_pc` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `PC_ID` int(10) unsigned NOT NULL,
  `TECNICOS_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `DATA_AGENDAMENTO` date DEFAULT NULL,
  `EMPRESA` varchar(255) DEFAULT NULL,
  `SETOR` varchar(255) DEFAULT NULL,
  `IDENTIFICACAO_PC` varchar(255) DEFAULT NULL,
  `VISTORIA_MARCADA_PARA` date DEFAULT NULL,
  `TECNICO` int(11) DEFAULT NULL,
  `TIPO_VISTORIA` varchar(255) DEFAULT NULL,
  `STATUS_VISTORIA` char(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `AGENDA_VISTORIA_PC_FKIndex1` (`SETORES_ID`),
  KEY `AGENDA_VISTORIA_PC_FKIndex2` (`TECNICOS_ID`),
  KEY `AGENDA_VISTORIA_PC_FKIndex3` (`PC_ID`),
  KEY `AGENDA_VISTORIA_PC_FKIndex4` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `agenda_vistoria_pc` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table biblioteca_softwares
#

DROP TABLE IF EXISTS `biblioteca_softwares`;
CREATE TABLE `biblioteca_softwares` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `DATA_CADASTRO` date DEFAULT NULL,
  `NOME_SOFTWARE` varchar(255) DEFAULT NULL,
  `TIP_SOFTWARE` varchar(255) DEFAULT NULL,
  `CATEGORIA` varchar(255) DEFAULT NULL,
  `SUBCATEGORIA` varchar(255) DEFAULT NULL,
  `FUNCAO` varchar(255) DEFAULT NULL,
  `SITE_DESENVOLVEDOR` varchar(255) DEFAULT NULL,
  `CAMINHO_LOGO` varchar(255) DEFAULT NULL,
  `DETALHE_FUNCAO` text,
  PRIMARY KEY (`ID`),
  KEY `BIBLIOTECA_SOFTWARES_FKIndex1` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `biblioteca_softwares` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table cadastro_acesso_remoto
#

DROP TABLE IF EXISTS `cadastro_acesso_remoto`;
CREATE TABLE `cadastro_acesso_remoto` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SERVICO` varchar(255) DEFAULT NULL,
  `USUARIO_MESTRE` varchar(255) DEFAULT NULL,
  `SENHA_MESTRE` varchar(255) DEFAULT NULL,
  `SENHA_ACESSO_PC` varchar(255) DEFAULT NULL,
  `CONF` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `cadastro_acesso_remoto` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table categoria_pc
#

DROP TABLE IF EXISTS `categoria_pc`;
CREATE TABLE `categoria_pc` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CATEGORIA` varchar(255) DEFAULT NULL,
  `DESCRICAO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `categoria_pc` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table detalhe
#

DROP TABLE IF EXISTS `detalhe`;
CREATE TABLE `detalhe` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AGENDA_VISTORIA_PC_ID` int(10) unsigned NOT NULL,
  `SERVICOS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `DETALHE_VISTORIA_PC_FKIndex1` (`AGENDA_VISTORIA_PC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `detalhe` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table detalhe_bs
#

DROP TABLE IF EXISTS `detalhe_bs`;
CREATE TABLE `detalhe_bs` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BIBLIOTECA_SOFTWARES_ID` int(10) unsigned NOT NULL,
  `NOME_VERSAO` varchar(255) DEFAULT NULL,
  `ATUALIZACAO_PACHT` varchar(255) DEFAULT NULL,
  `ANO` varchar(255) DEFAULT NULL,
  `CAMINHO_DRIVER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `DETALHE_BS_FKIndex1` (`BIBLIOTECA_SOFTWARES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `detalhe_bs` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table empresa
#

DROP TABLE IF EXISTS `empresa`;
CREATE TABLE `empresa` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `empresa` VALUES (1,'ROSA SHOCK PALMEIRAS');
INSERT INTO `empresa` VALUES (2,'ROSA SHOCK CIDADE');
INSERT INTO `empresa` VALUES (3,'ROSA SHOCK VI�OSA');
INSERT INTO `empresa` VALUES (4,'PNEUTEX');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table estabilizadores
#

DROP TABLE IF EXISTS `estabilizadores`;
CREATE TABLE `estabilizadores` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `VOLTAGEM` varchar(255) DEFAULT NULL,
  `SAIDAS` int(11) DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `DATA_COMPRA` date DEFAULT NULL,
  `IDENTIFICACAO` varchar(255) DEFAULT NULL,
  `INDICE_EST` int(11) DEFAULT NULL,
  `SAIDAS_DISPONIVEIS` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ESTABILIZADORES_FKIndex1` (`SETORES_ID`),
  KEY `ESTABILIZADORES_FKIndex2` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `estabilizadores` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table monitores
#

DROP TABLE IF EXISTS `monitores`;
CREATE TABLE `monitores` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `ESTABILIZADORES_ID` int(10) unsigned NOT NULL,
  `NOBREAK_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `NOME_MARCA_MODELO` varchar(255) DEFAULT NULL,
  `IDENTIFICACAO_MONITOR` varchar(255) DEFAULT NULL,
  `CONSUMO_KWH` int(11) DEFAULT NULL,
  `POL` varchar(255) DEFAULT NULL,
  `DATA_COMPRA` date DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `SAIDA_NOBREAK` int(11) DEFAULT NULL,
  `SAIDA_ESTABILIZADOR` int(11) DEFAULT NULL,
  `INDICE_MONITOR` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MONITORES_FKIndex1` (`SETORES_ID`),
  KEY `MONITORES_FKIndex2` (`NOBREAK_ID`),
  KEY `MONITORES_FKIndex3` (`ESTABILIZADORES_ID`),
  KEY `MONITORES_FKIndex4` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `monitores` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table mouse
#

DROP TABLE IF EXISTS `mouse`;
CREATE TABLE `mouse` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `IDENTIFICACAO_MOUSE` varchar(255) DEFAULT NULL,
  `DATA_COMPRA` varchar(255) DEFAULT NULL,
  `MARCA_MODELO` varchar(255) DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `TIPO_ENTRADA` varchar(255) DEFAULT NULL,
  `DATA_CADASTRO` date DEFAULT NULL,
  `INDICE_MOUSE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `MOUSE_FKIndex1` (`SETORES_ID`),
  KEY `MOUSE_FKIndex2` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `mouse` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table nobreak
#

DROP TABLE IF EXISTS `nobreak`;
CREATE TABLE `nobreak` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `SAIDAS` int(10) unsigned DEFAULT NULL,
  `VOLTAGEM` varchar(255) DEFAULT NULL,
  `KVA` varchar(255) DEFAULT NULL,
  `DATA_COMPRA` date DEFAULT NULL,
  `IDENTIFICACAO` varchar(255) DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `INDICE_NOBREAK` int(11) DEFAULT NULL,
  `SAIDAS_DISPONIVEIS` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `NOBREAK_FKIndex1` (`SETORES_ID`),
  KEY `NOBREAK_FKIndex2` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `nobreak` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table pc
#

DROP TABLE IF EXISTS `pc`;
CREATE TABLE `pc` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `POLITICAS_SUPORTE_ID` int(10) unsigned NOT NULL,
  `PORTCLIENTE_ID` int(10) unsigned NOT NULL,
  `PORTSERV_ID` int(10) unsigned NOT NULL,
  `SISTEMAS_OPERACIONAIS_ID` int(10) unsigned NOT NULL,
  `SUBCATEGORIA_PC_ID` int(10) unsigned NOT NULL,
  `CATEGORIA_PC_ID` int(10) unsigned NOT NULL,
  `REDES_VPN_ID` int(10) unsigned NOT NULL,
  `ESTABILIZADORES_ID` int(10) unsigned NOT NULL,
  `CADASTRO_ACESSO_REMOTO_ID` int(10) unsigned NOT NULL,
  `WORKGROUP_ID` int(10) unsigned NOT NULL,
  `NOBREAK_ID` int(10) unsigned NOT NULL,
  `SWITCH_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `IDENTIFICACAO_PC` varchar(255) DEFAULT NULL,
  `VS_EMITIDOS` int(11) DEFAULT NULL,
  `CONSUMO_KWH` double(10,2) DEFAULT NULL,
  `SUB_P` double(10,2) DEFAULT NULL,
  `SUB_H` double(10,2) DEFAULT NULL,
  `PMAE` varchar(255) DEFAULT NULL,
  `HD` varchar(255) DEFAULT NULL,
  `RAM` varchar(255) DEFAULT NULL,
  `CPU` varchar(255) DEFAULT NULL,
  `FONTE` varchar(255) DEFAULT NULL,
  `NIC1` varchar(255) DEFAULT NULL,
  `NIC2` varchar(255) DEFAULT NULL,
  `NIC3` varchar(255) DEFAULT NULL,
  `FAX_MODEM` varchar(255) DEFAULT NULL,
  `PC_CFTV` varchar(255) DEFAULT NULL,
  `PGPS` varchar(255) DEFAULT NULL,
  `PURA` varchar(255) DEFAULT NULL,
  `PWIFI` varchar(255) DEFAULT NULL,
  `P_CONTROLADORA_SCSI` varchar(255) DEFAULT NULL,
  `DRIVER_MIDIA1` varchar(255) DEFAULT NULL,
  `DRIVER_MIDIA2` varchar(255) DEFAULT NULL,
  `P_CONTROL_SCSI` varchar(255) DEFAULT NULL,
  `DISPOSITIVO1` varchar(255) DEFAULT NULL,
  `DISPOSITIVO2` varchar(255) DEFAULT NULL,
  `DISPOSITIVO3` varchar(255) DEFAULT NULL,
  `NOMEPC` varchar(255) DEFAULT NULL,
  `IP1` varchar(255) DEFAULT NULL,
  `IP2` varchar(255) DEFAULT NULL,
  `GT1` varchar(255) DEFAULT NULL,
  `GT2` varchar(255) DEFAULT NULL,
  `DNS1` varchar(255) DEFAULT NULL,
  `DNS2` varchar(255) DEFAULT NULL,
  `DIALUP_LINHA` varchar(255) DEFAULT NULL,
  `USER_DIALUP` varchar(255) DEFAULT NULL,
  `SENHA_DIALUP` varchar(255) DEFAULT NULL,
  `CONEXAO_PPOE` varchar(255) DEFAULT NULL,
  `USER_PPOE` varchar(255) DEFAULT NULL,
  `SENHA_PPOE` varchar(255) DEFAULT NULL,
  `CONF_SOFTBASICOS` text,
  `CONF_SOFTBANCARIOS` text,
  `CONF_SOFT_TERCEIROS` text,
  `CONF_CLIENTE_EMAIL` text,
  `CONF_DISPOSITIVOS` text,
  `INDICE_PC` int(11) DEFAULT NULL,
  `CAMINHO_DRIVERS` varchar(255) DEFAULT NULL,
  `CAMINHO_SOFT` varchar(255) DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `SAIDA_NOBREAK` int(11) DEFAULT NULL,
  `SAIDA_ESTABILIZADOR` int(11) DEFAULT NULL,
  `INDICE_PORTSERV` int(11) DEFAULT NULL,
  `INDICE_PORTCLI` int(11) DEFAULT NULL,
  `CLASSIFICACAO_TECNICA` varchar(255) DEFAULT NULL,
  `COMENTARIO_TECNICO` varchar(255) DEFAULT NULL,
  `FORMATACOES` int(11) DEFAULT NULL,
  `DESINFECCOES` int(11) DEFAULT NULL,
  `BOOTSECTORES` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `PC_FKIndex1` (`SETORES_ID`),
  KEY `PC_FKIndex2` (`SWITCH_ID`),
  KEY `PC_FKIndex3` (`NOBREAK_ID`),
  KEY `PC_FKIndex4` (`WORKGROUP_ID`),
  KEY `PC_FKIndex5` (`CADASTRO_ACESSO_REMOTO_ID`),
  KEY `PC_FKIndex6` (`ESTABILIZADORES_ID`),
  KEY `PC_FKIndex10` (`REDES_VPN_ID`),
  KEY `PC_FKIndex12` (`CATEGORIA_PC_ID`),
  KEY `PC_FKIndex13` (`SUBCATEGORIA_PC_ID`),
  KEY `PC_FKIndex14` (`SISTEMAS_OPERACIONAIS_ID`),
  KEY `PC_FKIndex15` (`PORTSERV_ID`),
  KEY `PC_FKIndex16` (`PORTCLIENTE_ID`),
  KEY `PC_FKIndex17` (`POLITICAS_SUPORTE_ID`),
  KEY `PC_FKIndex18` (`EMPRESA_ID`),
  KEY `PC_FKIndex20` (`NOBREAK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table pcausas_mapeadas
#

DROP TABLE IF EXISTS `pcausas_mapeadas`;
CREATE TABLE `pcausas_mapeadas` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME` varchar(255) DEFAULT NULL,
  `DESCRICAO` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `pcausas_mapeadas` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table politicas_suporte
#

DROP TABLE IF EXISTS `politicas_suporte`;
CREATE TABLE `politicas_suporte` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME_POLITICA` int(10) unsigned DEFAULT NULL,
  `TIPO` int(10) unsigned DEFAULT NULL,
  `DESCRICAO` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `politicas_suporte` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table portcliente
#

DROP TABLE IF EXISTS `portcliente`;
CREATE TABLE `portcliente` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TIPOS_PORTA_ID` int(10) unsigned NOT NULL,
  `SWITCH_ID` int(10) unsigned NOT NULL,
  `IDENTIFICACAO_PORTA` varchar(255) DEFAULT NULL,
  `STATUS_OPERACAO` varchar(255) DEFAULT NULL,
  `STATUS_USO` varchar(255) DEFAULT NULL,
  `VELOCIDADE` varchar(255) DEFAULT NULL,
  `OBS` text,
  PRIMARY KEY (`ID`),
  KEY `PORTCLIENTE_FKIndex1` (`SWITCH_ID`),
  KEY `PORTCLIENTE_FKIndex2` (`TIPOS_PORTA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `portcliente` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table portserv
#

DROP TABLE IF EXISTS `portserv`;
CREATE TABLE `portserv` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TIPOS_PORTA_ID` int(10) unsigned NOT NULL,
  `SWITCH_ID` int(10) unsigned NOT NULL,
  `IDENTIFICACAO_PORTA` varchar(255) DEFAULT NULL,
  `STATUS_OPERACAO` varchar(255) DEFAULT NULL,
  `STATUS_USO` varchar(255) DEFAULT NULL,
  `VELOCIDADE` varchar(255) DEFAULT NULL,
  `OBS` text,
  PRIMARY KEY (`ID`),
  KEY `PORTSERV_FKIndex1` (`SWITCH_ID`),
  KEY `PORTSERV_FKIndex2` (`TIPOS_PORTA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `portserv` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table rat
#

DROP TABLE IF EXISTS `rat`;
CREATE TABLE `rat` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `SERVICOS_MAPEADOS_ID` int(10) unsigned NOT NULL,
  `PCAUSAS_MAPEADAS_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `TECNICOS_ID` int(10) unsigned NOT NULL,
  `INDICE_RAT` int(11) DEFAULT NULL,
  `DATA_ABERTURA` int(11) DEFAULT NULL,
  `HORA_ABERTURA` int(11) DEFAULT NULL,
  `SOLICITANTE` int(11) DEFAULT NULL,
  `DESCRICAO_PROBLEMA` varchar(255) DEFAULT NULL,
  `AGENDADO_DATA` int(11) DEFAULT NULL,
  `HORA_AGENDADA` int(11) DEFAULT NULL,
  `INICIO_ATENDIMENTO` int(11) DEFAULT NULL,
  `TERMINO_ATENDI` int(11) DEFAULT NULL,
  `SOLUCAO` varchar(255) DEFAULT NULL,
  `PARECER_TEC` varchar(255) DEFAULT NULL,
  `STATUS_RAT` varchar(255) DEFAULT NULL,
  `BOOTSECTOR` int(11) DEFAULT NULL,
  `TRAVA_WINDOWS` int(11) DEFAULT NULL,
  `FORMATACAO` int(11) DEFAULT NULL,
  `TREINAMENTO` int(11) DEFAULT NULL,
  `TROCA_COMPONENTE` int(11) DEFAULT NULL,
  `TROCA_PERIFERICO` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `RAT_FKIndex2` (`TECNICOS_ID`),
  KEY `RAT_FKIndex6` (`SETORES_ID`),
  KEY `RAT_FKIndex3` (`PCAUSAS_MAPEADAS_ID`),
  KEY `RAT_FKIndex4` (`SERVICOS_MAPEADOS_ID`),
  KEY `RAT_FKIndex5` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `rat` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table rat_detalhe
#

DROP TABLE IF EXISTS `rat_detalhe`;
CREATE TABLE `rat_detalhe` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RAT_ID` int(10) unsigned NOT NULL,
  `NOME_SERVICO` varchar(255) DEFAULT NULL,
  `DESCRICAO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `RAT_DETALHE_FKIndex1` (`RAT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `rat_detalhe` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table redes_vpn
#

DROP TABLE IF EXISTS `redes_vpn`;
CREATE TABLE `redes_vpn` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME_REDE` varchar(255) DEFAULT NULL,
  `LOGIN` varchar(255) DEFAULT NULL,
  `SENHA` varchar(255) DEFAULT NULL,
  `CONF_CLIENTE` text,
  `CONF_SERVIDOR` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `redes_vpn` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table servicos_mapeados
#

DROP TABLE IF EXISTS `servicos_mapeados`;
CREATE TABLE `servicos_mapeados` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME` varchar(255) DEFAULT NULL,
  `DESCRICAO` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `servicos_mapeados` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table setores
#

DROP TABLE IF EXISTS `setores`;
CREATE TABLE `setores` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `setores` VALUES (1,'FINANCEIRO');
INSERT INTO `setores` VALUES (2,'COMPRAS');
INSERT INTO `setores` VALUES (3,'VENDAS');
INSERT INTO `setores` VALUES (4,'GERENCIA');
/*!40000 ALTER TABLE `setores` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table sistemas_operacionais
#

DROP TABLE IF EXISTS `sistemas_operacionais`;
CREATE TABLE `sistemas_operacionais` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NOME` varchar(255) DEFAULT NULL,
  `VERSAO` varchar(255) DEFAULT NULL,
  `ATUALIZACOES` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `sistemas_operacionais` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table subcategoria_pc
#

DROP TABLE IF EXISTS `subcategoria_pc`;
CREATE TABLE `subcategoria_pc` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SUBCATEGORIA` varchar(255) DEFAULT NULL,
  `DESCRICAO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `subcategoria_pc` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table switch
#

DROP TABLE IF EXISTS `switch`;
CREATE TABLE `switch` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `NOME_MARCA_MODELO` varchar(255) DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `DATA_COMPRA` date DEFAULT NULL,
  `PORTAS` int(11) DEFAULT NULL,
  `CONSUMO_KWH` int(11) DEFAULT NULL,
  `OBS` text,
  `PORTAS_DISPONIVEIS` int(11) DEFAULT NULL,
  `INDICE_SWITCH` int(11) DEFAULT NULL,
  `LOCALIZACAO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SWITCH_FKIndex1` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `switch` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table teclados
#

DROP TABLE IF EXISTS `teclados`;
CREATE TABLE `teclados` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `IDENTIFICACAO_TECLADO` varchar(255) DEFAULT NULL,
  `DATA_COMPRA` date DEFAULT NULL,
  `MARCA_MODELO` varchar(255) DEFAULT NULL,
  `VALOR_EQUIPAMENTO` double(10,2) DEFAULT NULL,
  `TIPO_ENTRADA` varchar(255) DEFAULT NULL,
  `INDICE_TECLADO` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `TECLADOS_FKIndex1` (`SETORES_ID`),
  KEY `TECLADOS_FKIndex3` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `teclados` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table tecnicos
#

DROP TABLE IF EXISTS `tecnicos`;
CREATE TABLE `tecnicos` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DATA_CADASTRO` date DEFAULT NULL,
  `NOME` varchar(255) DEFAULT NULL,
  `TEL1` varchar(255) DEFAULT NULL,
  `TEL2` varchar(255) DEFAULT NULL,
  `TEL3` varchar(255) DEFAULT NULL,
  `IMS1` varchar(255) DEFAULT NULL,
  `IMS2` varchar(255) DEFAULT NULL,
  `LOGRADOURO` varchar(255) DEFAULT NULL,
  `COMPLEMENTO` varchar(255) DEFAULT NULL,
  `BAIRRO` varchar(255) DEFAULT NULL,
  `CIDADE` varchar(255) DEFAULT NULL,
  `CEP` varchar(255) DEFAULT NULL,
  `UF` varchar(255) DEFAULT NULL,
  `FOTO` varchar(255) DEFAULT NULL,
  `CPF` varchar(255) DEFAULT NULL,
  `RG` varchar(255) DEFAULT NULL,
  `CREA` varchar(255) DEFAULT NULL,
  `HABLITACAO` varchar(255) DEFAULT NULL,
  `RATS_EFETUADOS` int(11) DEFAULT NULL,
  `TOTAL_HORAS_ATENDIMENTO` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `tecnicos` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table tipos_porta
#

DROP TABLE IF EXISTS `tipos_porta`;
CREATE TABLE `tipos_porta` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TIPO` varchar(255) DEFAULT NULL,
  `DESCRICAO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `tipos_porta` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table usuario
#

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NIVEL` char(1) DEFAULT NULL,
  `CARGO` varchar(255) DEFAULT NULL,
  `NOME` varchar(255) DEFAULT NULL,
  `LOGIN` varchar(255) DEFAULT NULL,
  `SENHA` varchar(255) DEFAULT NULL,
  `DATA_CADASTRO` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `usuario` VALUES (1,NULL,NULL,'NILDO','NILDO','123456',NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table usuarios_pc
#

DROP TABLE IF EXISTS `usuarios_pc`;
CREATE TABLE `usuarios_pc` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `NOME` varchar(255) DEFAULT NULL,
  `CURSO_INFO` varchar(255) DEFAULT NULL,
  `DESCRICAO` text,
  `QUANT_S` int(11) DEFAULT NULL,
  `QUANT_HORA_TREINAMENTO` varchar(255) DEFAULT NULL,
  `QUANT_TREINAMENTO` int(11) DEFAULT NULL,
  `SETOR` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `USUARIOS_PC_FKIndex1` (`SETORES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `usuarios_pc` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table workgroup
#

DROP TABLE IF EXISTS `workgroup`;
CREATE TABLE `workgroup` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int(10) unsigned NOT NULL,
  `SETORES_ID` int(10) unsigned NOT NULL,
  `NOME_GRUPO` varchar(255) DEFAULT NULL,
  `DESCRICAO` text,
  PRIMARY KEY (`ID`),
  KEY `WORKGROUP_FKIndex2` (`SETORES_ID`),
  KEY `WORKGROUP_FKIndex3` (`EMPRESA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `workgroup` ENABLE KEYS */;
UNLOCK TABLES;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
