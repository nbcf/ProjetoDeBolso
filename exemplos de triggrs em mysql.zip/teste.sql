# MySQL-Front 5.0  (Build 1.0)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: teste
# ------------------------------------------------------
# Server version 5.1.50-community

#
# Table structure for table entrada
#

DROP TABLE IF EXISTS `entrada`;
CREATE TABLE `entrada` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `quantidade` varchar(255) DEFAULT NULL,
  `produto` varchar(255) DEFAULT NULL,
  `cod_produto` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
INSERT INTO `entrada` VALUES (1,'20','lapis',1);
INSERT INTO `entrada` VALUES (2,'30','lapis',1);
INSERT INTO `entrada` VALUES (3,'99','lapis',1);
INSERT INTO `entrada` VALUES (4,'99','borracha',2);
INSERT INTO `entrada` VALUES (5,'50',NULL,2);
INSERT INTO `entrada` VALUES (6,'100',NULL,2);
INSERT INTO `entrada` VALUES (7,'500',NULL,2);
INSERT INTO `entrada` VALUES (8,'2','LAPIS',1);
/*!40000 ALTER TABLE `entrada` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table produto
#

DROP TABLE IF EXISTS `produto`;
CREATE TABLE `produto` (
  `Codigo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estoque` varchar(255) DEFAULT NULL,
  `nome` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `produto` VALUES (1,'50','lapis');
INSERT INTO `produto` VALUES (2,'301','borracha');
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table venda
#

DROP TABLE IF EXISTS `venda`;
CREATE TABLE `venda` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Produto_cod` int(10) unsigned DEFAULT NULL,
  `qtde` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
INSERT INTO `venda` VALUES (1,2,'5');
INSERT INTO `venda` VALUES (2,1,'1');
INSERT INTO `venda` VALUES (3,1,'1');
INSERT INTO `venda` VALUES (4,2,'5');
INSERT INTO `venda` VALUES (5,2,'5');
INSERT INTO `venda` VALUES (6,1,'1');
INSERT INTO `venda` VALUES (7,1,'1');
INSERT INTO `venda` VALUES (8,1,'1');
INSERT INTO `venda` VALUES (9,1,'1');
INSERT INTO `venda` VALUES (10,1,'60');
INSERT INTO `venda` VALUES (11,2,'14');
INSERT INTO `venda` VALUES (12,1,'3');
INSERT INTO `venda` VALUES (13,1,'10');
INSERT INTO `venda` VALUES (14,1,'40');
INSERT INTO `venda` VALUES (15,2,'50');
INSERT INTO `venda` VALUES (16,2,'1');
INSERT INTO `venda` VALUES (17,1,'1');
INSERT INTO `venda` VALUES (18,2,'99');
INSERT INTO `venda` VALUES (19,2,'1');
INSERT INTO `venda` VALUES (20,2,'0');
INSERT INTO `venda` VALUES (21,2,'199');
INSERT INTO `venda` VALUES (22,1,'1');
/*!40000 ALTER TABLE `venda` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for trigger entrada
#

DROP TRIGGER IF EXISTS `entrada`;
CREATE DEFINER='root'@`localhost` TRIGGER `entrada` AFTER INSERT ON `entrada`
  FOR EACH ROW begin
update  produto set estoque=estoque+New.quantidade
where produto.codigo=New.cod_produto;
end;


#
# Source for trigger saida
#

DROP TRIGGER IF EXISTS `saida`;
CREATE DEFINER='root'@`localhost` TRIGGER `saida` AFTER INSERT ON `venda`
  FOR EACH ROW begin
update produto set estoque=estoque-New.qtde
where produto.codigo=New.Produto_cod;
end;


/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
